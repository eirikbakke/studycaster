package com.maxmind.geoip;

public class Region{
  public String countryCode;
  public String countryName;
  public String region;
}

